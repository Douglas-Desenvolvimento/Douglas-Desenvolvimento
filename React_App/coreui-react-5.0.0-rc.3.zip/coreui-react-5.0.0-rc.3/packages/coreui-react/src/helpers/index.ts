import { PolymorphicRefForwardingComponent } from './polymorphicComponent'

export { PolymorphicRefForwardingComponent }
