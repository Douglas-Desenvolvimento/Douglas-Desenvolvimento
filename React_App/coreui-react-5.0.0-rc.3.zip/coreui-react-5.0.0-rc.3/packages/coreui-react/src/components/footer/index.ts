import { CFooter } from './CFooter'

export { CFooter }
