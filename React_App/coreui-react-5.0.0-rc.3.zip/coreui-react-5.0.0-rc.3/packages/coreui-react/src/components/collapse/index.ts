import { CCollapse } from './CCollapse'

export { CCollapse }
