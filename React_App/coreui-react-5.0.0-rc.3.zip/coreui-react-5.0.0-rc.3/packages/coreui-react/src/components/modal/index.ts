import { CModal } from './CModal'
import { CModalBody } from './CModalBody'
import { CModalContent } from './CModalContent'
import { CModalDialog } from './CModalDialog'
import { CModalFooter } from './CModalFooter'
import { CModalHeader } from './CModalHeader'
import { CModalTitle } from './CModalTitle'

export { CModal, CModalBody, CModalContent, CModalDialog, CModalFooter, CModalHeader, CModalTitle }
