import { CCallout } from './CCallout'

export { CCallout }
