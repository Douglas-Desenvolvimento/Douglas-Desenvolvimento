import { CPlaceholder } from './CPlaceholder'

export { CPlaceholder }
